import {HttpHeaders} from '@angular/common/http';

export const headers = new HttpHeaders({'X-Auth-Token': '3758982f8a674aca880614b3f8bb353e'});
export const URL = 'https://api.football-data.org';


